import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';


class CartTab extends StatefulWidget
{

  @override
  CartState createState() => CartState();

}

class CartState extends State<CartTab>
{
  List<String> cartItems = [];
  double totalAmount = 0.0;



  @override
  void initState() {
    super.initState();
    loadCartItems();
  }

  loadCartItems() async
  {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    setState(() {
      cartItems = prefs.getStringList('cartItems') ?? [];
      calculateTotal();
    });
  }

  void calculateTotal() {
    totalAmount = 0.0;
    for (String cartItemName in cartItems) {
      final double itemPrice = itemPrices[cartItemName.trim()] ?? 0.0;
      print('CartItem: $cartItemName, Price: $itemPrice');
      totalAmount += itemPrice;
    }
    print('Total Amount: $totalAmount');
  }



  @override
  Widget build(BuildContext context)
  {
    var today = DateTime.now();
    var dateFormat = DateFormat('dd-MM-yyyy');
    String currentDate = dateFormat.format(today);

    return Scaffold(
      appBar: AppBar(
        title: Text("Cart", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,

          children: [

            SizedBox(height: 20),
            Text(currentDate, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
            SizedBox(height: 20),
            Expanded(
                child: ListView.builder(
                  itemCount: cartItems.length,
                    itemBuilder: (context, index)
                    {
                      return ListTile(


                        title: Text(cartItems[index]),
              );
            }),),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Total: ", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                      Text(" \$${totalAmount.toString()}", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),

                  ElevatedButton(
                    onPressed: ()
                    {
                      clearCart();
                    }, child: Text("Checkout"),),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void clearCart() async
  {
      SharedPreferences prefs = await SharedPreferences.getInstance();

      await prefs.remove('cartItems');

      setState(() {
        cartItems = [];
        totalAmount = 0.0;
      });

  }

  final Map<String, double> itemPrices = {
    'Vegetables And Poached Egg': 12.50,
    'Avocado Salad': 19.28,
    'Pancakes': 15.32,
    'Appetizer': 12.12,
    'Hot dog': 12.12,
    'Chicken Fajitas': 12.12,
    'Burger': 12.12,
    'Pizza': 12.12,
    'Cold Coffee': 12.12,
    'Mocktail': 12.12,

  };

}

class CartItem {
  final String name;
  final String image;
  final double price;

  CartItem(this.name, this.image, this.price);


}
