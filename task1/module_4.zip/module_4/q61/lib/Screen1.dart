import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'CartTab.dart';

class Screen1 extends StatefulWidget
{
  @override
  Screen1State createState() => Screen1State();
}


class Screen1State extends State<Screen1>
{
  int _currentIndex = 0;
  late SharedPreferences prefs;
  double totalAmount = 0.0;

  final List<Widget> _tabs = [
    MenuTab(),
     CartTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: _tabs[_currentIndex],
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (int index) {
              setState(() {
                _currentIndex = index;
              });
              },
            items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.book),
              label: 'Menu',
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart),
              label: 'Cart',
            ),
          ],
          ),
      ),

    );
  }
}




class MenuTab extends StatefulWidget
{
  @override
  MenuState createState() => MenuState();

}

class MenuState extends State<MenuTab>
{

  List<Choice> choice = [
    Choice('https://begrimed-executions.000webhostapp.com/images/g1.jpeg','Vegetables And \n Poached Egg','12.50'),
    Choice('https://begrimed-executions.000webhostapp.com/images/g2.jpeg','Avocado Salad','19.28',),
    Choice('https://begrimed-executions.000webhostapp.com/images/g3.jpeg','Pancakes','15.32'),
    Choice('https://begrimed-executions.000webhostapp.com/images/g4.jpeg','Appetizer','12.12',),
    Choice('https://begrimed-executions.000webhostapp.com/images/g5.jpeg','Hot dog','12.12',),

    Choice('https://begrimed-executions.000webhostapp.com/images/g6.jpg','Chicken Fajitas','12.12',),
    Choice('https://begrimed-executions.000webhostapp.com/images/g7.jpeg','Burger','12.12',),
    Choice('https://begrimed-executions.000webhostapp.com/images/g8.jpeg','Pizza','12.12',),
    Choice('https://begrimed-executions.000webhostapp.com/images/g9.jpeg','Cold Coffee','12.12',),
    Choice('https://begrimed-executions.000webhostapp.com/images/g10.jpg','Mocktail','12.12',),

  ];


  @override
  Widget build(BuildContext context)
  {

        return Scaffold(
          appBar: AppBar(title: Text("  Menu",style: TextStyle(fontWeight: FontWeight.bold ,color: Colors.black),),
            backgroundColor: Colors.white,
            elevation: 0,
            bottom: TabBar(
                isScrollable: true,
                unselectedLabelColor: Colors.black,
                labelColor: Colors.black,
                indicatorSize: TabBarIndicatorSize.label,
                indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: Colors.orange),
                tabs: [
                  Tab(
                    child: Container(
                      height: 50,
                      width: 100,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(color: Colors.orange, width: 1)
                      ),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text("Recommend"),
                      ),
                    ),
                  ),
                  Tab(
                    child: Container(
                      height: 50,
                      width: 100,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(color: Colors.orange, width: 1)),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text("Popular"),
                      ),
                    ),
                  ),
                  Tab(
                    child: Container(
                      height: 50,
                      width: 100,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(color: Colors.orange, width: 1)),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text("Noodeles"),
                      ),
                    ),
                  ),
                  Tab(
                    child: Container(
                      height: 50,
                      width: 100,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(color: Colors.orange, width: 1)),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text("Pizza"),
                      ),
                    ),
                  ),
                ]),
          ),
          body: Center(
            child: Padding(
              padding: EdgeInsets.only(top: 20,bottom: 10),
              child: Column(
              children: [
                Expanded(
                  child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10.0,
                      mainAxisSpacing: 10.0,
                    ),
                    itemCount: choice.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: ()
                        {

                        },
                        child: Card(
                          elevation: 5.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Image.network(choice[index].image, height: 100),
                              Text(
                                choice[index].name,
                                style: TextStyle(fontSize: 15.0),
                              ),
                              SizedBox(height: 5.0),

                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('\$${choice[index].price.toString()}',
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(width: 25),
                                  Container(
                                    color: Colors.orange,
                                    alignment: Alignment.center,
                                    height: 25,
                                    width: 25,
                                    child: Center(
                                      child: IconButton(
                                        padding: EdgeInsets.all(0.5),

                                        onPressed: () async {

                                          SharedPreferences prefs = await SharedPreferences.getInstance();
                                          List<String> cartItems = prefs.getStringList('cartItems') ?? [];

                                          cartItems.add(choice[index].name + "                        " +
                                              "          " + choice[index].price);

                                          await prefs.setStringList('cartItems', cartItems);

                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: Text('Added ${choice[index].name} to cart'),
                                            ),
                                          );

                                        },icon: Icon(Icons.add),),
                                    ),
                                  ),
                                ],
                              ),

                            ],
                          ),
                        ),
                      );
                    },
                  ),

                ),
              ],
              ),
            ),
          ),
        );

  }

}

class Choice {
  final String image;
  final String name;
  final String price;


  Choice(this.image, this.name, this.price);
}

