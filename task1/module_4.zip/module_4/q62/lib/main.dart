import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AlertDialogDemo(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AlertDialogDemo extends StatelessWidget {
  void _showAlertDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context)
      {
        return AlertDialog(

          title: Text("Alert Dialog Title"),

          content: Column(

            mainAxisSize: MainAxisSize.min, // To make the dialog compact
            children: [

              Icon(
                Icons.warning,
                color: Colors.orange,
                size: 40,
              ),

              SizedBox(height: 20),

              Text("This is the alert dialog description"),
            ],
          ),

          actions: [

            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Alert Dialog"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            _showAlertDialog(context);
          },
          child: Text("Show Alert Dialog"),
        ),
      ),
    );
  }
}
