import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AlertDialogDemo(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AlertDialogDemo extends StatelessWidget
{
  void _showAlertDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(

          title: Text("Alert Dialog Title"),

          content: Text("This is the alert dialog content."),

          actions: [

            TextButton(
              onPressed: () {
                Navigator.pop(context);
                positive_toast();
              },
              child: Text("Positive"),
            ),

            TextButton(
              onPressed: () {
                Navigator.pop(context);
                negative_toast();
              },
              child: Text("Negative"),
            ),

            TextButton(
              onPressed: () {
                Navigator.pop(context);
                neutral_toast();
              },
              child: Text("Neutral"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Alert Dialog"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            _showAlertDialog(context);
          },
          child: Text("Show Alert Dialog"),
        ),
      ),
    );
  }

  void positive_toast()
  {
      Fluttertoast.showToast(
        msg: 'Positive Button Clicked',
        toastLength:Toast.LENGTH_SHORT,
        gravity:ToastGravity.BOTTOM,
        backgroundColor:Colors.grey,
        textColor: Colors.black,
      );
  }

  void negative_toast()
  {
    Fluttertoast.showToast(
      msg: 'Negative Button Clicked',
      toastLength:Toast.LENGTH_SHORT,
      gravity:ToastGravity.BOTTOM,
      backgroundColor:Colors.grey,
      textColor: Colors.black,
    );
  }

  void neutral_toast()
  {
    Fluttertoast.showToast(
      msg: 'Neutral Button Clicked',
      toastLength:Toast.LENGTH_SHORT,
      gravity:ToastGravity.BOTTOM,
      backgroundColor:Colors.grey,
      textColor: Colors.black,
    );
  }
}

