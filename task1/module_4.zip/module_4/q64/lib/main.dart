import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(
      MaterialApp(
        home: selectionAlert(),),);
}


class selectionAlert extends StatefulWidget
{
  @override
  selectionState createState() => selectionState();


}

class selectionState extends State<selectionAlert>
{
  String selectedCity  = '';

  List<String> cities = [
    'Vadodara',
    'Ahmedabad',
    'Surat',
    'Rajkot',
  ];

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Selction Alert Dialog"),),

      body: Center(

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            Text("Selected City:", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),

           SizedBox(height: 10),

           Text(selectedCity),

            SizedBox(height: 10),

           ElevatedButton(onPressed: (){

             _showCitySelectionDialog();

             }, child: Text("Select City", style: TextStyle(fontSize: 20),))
          ],
        ),
      ),
    );
  }

  void _showCitySelectionDialog()
  {
    showDialog(context: context, builder: (BuildContext context)
    {
      return AlertDialog(

        title: Text("Select a City"),
        content: SingleChildScrollView(
          child: ListBody(
            children: cities.map((city)
      {
        return RadioListTile(
            title: Text(city),
            value: city,
            groupValue: selectedCity,
            onChanged: (value)
            {
              setState(() {
                selectedCity = city.toString();
              });

              Navigator.pop(context);
            }
            );

          }).toList()
          ),
        ),
      );


    });
  }
}


