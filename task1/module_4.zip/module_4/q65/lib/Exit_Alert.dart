import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ExitAlert extends StatefulWidget
{
  @override
  ExitState createState() => ExitState();


}

class ExitState extends State<ExitAlert>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Exit Alert Dialog"),),

      body: Center(

        child: Column(

          children: [

            SizedBox(height: 300),

            Text("If you want to Exit the Application Click the Button",
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),),

            SizedBox(height: 20),

            ElevatedButton(onPressed: (){

              _showAlertDialog(context);

            }, child: Text("Click Me"),),
          ],
        ),
      ),
    );
  }

  void _showAlertDialog(BuildContext context)
  {
    showDialog(
        context: context,
        builder: (BuildContext context) {
      return AlertDialog(

        title: Text("Exit The Applicarion"),

        content: Text("Are you sure you want to Exit the Application"),

        actions: [

          TextButton(onPressed: (){

            Navigator.pop(context);

          }, child: Text("Yes"),),

          TextButton(onPressed: (){

            Navigator.pop(context);

          }, child: Text("No"),),
        ],


      );


    }
    );
  }

}