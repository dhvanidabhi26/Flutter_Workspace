import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(
    home: SelectDate(),
    debugShowCheckedModeBanner: false,
  ));
}

class SelectDate extends StatefulWidget
{
  @override
  dateState createState() => dateState();


}

class dateState extends State<SelectDate>
{
  DateTime selecteddate = DateTime.now();

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Select Date"),),
      body: Center(

        child: Column(
          mainAxisSize: MainAxisSize.min,

          children: [

            ElevatedButton(onPressed: (){

              _selectDate(context);

            }, child: Text("Select Date")),

            SizedBox(height: 15),

            Text("Selected Date is: \n $selecteddate", style: TextStyle(fontSize: 17),),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async
  {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selecteddate,
        firstDate: DateTime(2015,1),
        lastDate: DateTime(2101));

    if(picked != null && picked != selecteddate)
      {
        setState(() {
          selecteddate = picked;
        });
      }

  }

}