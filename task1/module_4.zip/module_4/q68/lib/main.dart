import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyListView(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyListView extends StatefulWidget {
  @override
  _MyListViewState createState() => _MyListViewState();
}

class _MyListViewState extends State<MyListView> {
  List<String> items = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List with Context Menu"),
      ),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(items[index]),
            onTap: () {
              // Handle the view action here.
              _showItemDetails(items[index]);
            },
            onLongPress: () {
              // Display the context menu for edit and delete options.
              _showContextMenu(context, items[index]);
            },
          );
        },
      ),
    );
  }

  void _showItemDetails(String item) {
    // Implement your view action here.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("View Item"),
          content: Text("You selected: $item"),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("Close"),
            ),
          ],
        );
      },
    );
  }

  void _showContextMenu(BuildContext context, String item) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: Icon(Icons.edit), // Add leading icon
              title: Text("Edit"),
              onTap: () {
                // Handle the edit action here.
                _editItem(item);
                Navigator.of(context).pop();
              },
            ),
            ListTile(
              leading: Icon(Icons.delete), // Add leading icon
              title: Text("Delete"),
              onTap: () {
                // Handle the delete action here.
                _deleteItem(item);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _editItem(String item) {
    print("Editing item: $item");
  }

  void _deleteItem(String item) {
    setState(() {
      items.remove(item);
    });
    print("Deleted item: $item");
  }
}
