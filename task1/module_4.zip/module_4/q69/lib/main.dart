import 'package:flutter/material.dart';

void main()
{
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gmail Clone',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: EmailListScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class EmailListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inbox'),
      ),
      body: ListView.builder(
        itemCount: 20,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
              child: Text('A'),
            ),
            title: Text('Sender Name'),
            subtitle: Text('Subject'),
            onTap: ()
            {
              Navigator.push(context, MaterialPageRoute(builder: (context) => EmailDetailScreen()));
            },
          );
        },
      ),
    );
  }
}

class EmailDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Email Detail'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Subject: Lorem ipsum dolor sit amet',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'From: sender@example.com',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('To: recipient@example.com'),
            SizedBox(height: 10),
            Text('Date: January 1, 2023'),
            SizedBox(height: 20),
            Text(
              'Message:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
                  'Pellentesque euismod vel odio sed facilisis. Donec eu '
                  'volutpat est. Nullam sed vulputate turpis. In hac habitasse '
                  'platea dictumst.',
            ),
          ],
        ),
      ),
    );
  }
}
