import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MyApp());
}

class AudioTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Audio'),
      ),
      body: Center(
        child: Text('Audio Page - Dummy Data'),
      ),
    );
  }
}

class VideoTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Video'),
      ),
      body: Center(
        child: Text('Video Page - Dummy Data'),
      ),
    );
  }
}

class GalleryTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gallery'),
      ),
      body: Center(
        child: Text('Gallery Page - Dummy Data'),
      ),
    );
  }
}


class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      title: 'Media App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MediaApp(),
    );
  }
}

class MediaApp extends StatefulWidget
{
  @override
  MediaState createState() => MediaState();


}

class MediaState extends State<MediaApp>
{
  int _currentIndex = 0;

  final List<Widget> _tabs = [GalleryTab(), AudioTab(), VideoTab()];

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Media App"),),

      body: _tabs[_currentIndex],

      bottomNavigationBar: BottomNavigationBar(

        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },

        items:
      [
        BottomNavigationBarItem(
            icon: Icon(Icons.audiotrack),
          label: "Audio",
          backgroundColor: Colors.black,
        ),

        BottomNavigationBarItem(
          icon: Icon(Icons.video_collection_sharp),
          label: "Video",
          backgroundColor: Colors.black,
        ),

        BottomNavigationBarItem(
          icon: Icon(Icons.photo_outlined),
          label: "Gallery",
          backgroundColor: Colors.white,
        ),
      ],
      ),

    );
  }
}