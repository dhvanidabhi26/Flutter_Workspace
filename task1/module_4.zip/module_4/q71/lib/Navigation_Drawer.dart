import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'audio.dart';

class NewTab extends StatefulWidget
{
  @override
  NewTabState createState() => NewTabState();


}

class NewTabState extends State<NewTab>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Navigation Drawer"),),

      body: Center(),

      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.all(0.0),
          children: [

            DrawerHeader(
            child: Text(
            'Navigation Drawer',
              style: TextStyle(
                fontSize: 24,
                color: Colors.white,
              ),
            ),
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
          ),

            ListTile(
              leading: Icon(Icons.audiotrack_rounded), title: Text("Audio"),
              onTap: ()
              {
                Navigator.push(context, MaterialPageRoute(builder: (context) => NewTab2()));
              },
            ),

            ListTile(
              leading: Icon(Icons.videocam), title: Text("Video"),
              onTap: ()
              {
                Navigator.push(context, MaterialPageRoute(builder: (context) => NewTab3()));
              },
            ),

            ListTile(
              leading: Icon(Icons.photo_outlined), title: Text("Gallery"),
              onTap: ()
              {
                Navigator.push(context, MaterialPageRoute(builder: (context) => NewTab4()));
              },
            ),
          ],
        ),
      ),
    );
  }

}