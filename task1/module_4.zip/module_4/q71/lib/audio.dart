import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NewTab2 extends StatefulWidget
{
  @override
  NewTab2State createState() => NewTab2State();


}

class NewTab2State extends State<NewTab2>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Audio"),),

      body: Center(

        child: Column(

          children: [

            SizedBox(height: 200),

            Image.network("https://begrimed-executions.000webhostapp.com/images/audio.jpeg", height: 200, width: 200),
          ],
        ),
      ),
    );
  }

}

class NewTab3 extends StatefulWidget
{
  @override
  NewTab3State createState() => NewTab3State();


}

class NewTab3State extends State<NewTab3>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Video"),),

      body: Center(

        child: Column(

          children: [

            SizedBox(height: 200),

            Image.network("https://begrimed-executions.000webhostapp.com/images/video.jpeg", height: 200, width: 200),
          ],
        ),
      ),
    );
  }

}

class NewTab4 extends StatefulWidget
{
  @override
  NewTab4State createState() => NewTab4State();


}

class NewTab4State extends State<NewTab4>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Gallery"),),

      body: Center(

        child: Column(

          children: [

            SizedBox(height: 200),

            Image.network("https://begrimed-executions.000webhostapp.com/images/gallery.jpeg", height: 200, width: 200),
          ],
        ),
      ),
    );
  }

}