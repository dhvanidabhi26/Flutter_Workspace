import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main()
{
  runApp(MyApp());
}

class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      home: NewApp(),
      debugShowCheckedModeBanner: false,
    );
  }

}

class NewApp extends StatefulWidget
{
  @override
  NewAppState createState() => NewAppState();


}

class NewAppState extends State<NewApp>
{

  void _showAlertDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(

          title: Text("Alert Dialog"),

          content: Text("You want to allow permissions to interact with your contacts"),

          actions: [

            TextButton(
              onPressed: () {
                makePhoneCall();
              },
              child: Text("Allow"),
            ),

            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Deny"),
            ),

          ],
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(title: Text("My App"),),
      body: Center(
        child: Column(
          children: [

            SizedBox(height: 250.0),

          Text(
          'Welcome to Phone Call App!',
          style: TextStyle(fontSize: 20.0),
        ),

          SizedBox(height: 20.0),

          ElevatedButton(
            onPressed: ()
            {
              _showAlertDialog(context);
            },
            child: Text('Make a Phone Call'),
          ),
          ],
        ),
      ),
    );
  }

  void makePhoneCall()
  {

      var url = Uri.parse("tel:8758268869");
      launchUrl(url);
  }

}