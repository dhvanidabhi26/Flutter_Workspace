import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MyApp());
}

class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      home: MyAnimation(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyAnimation extends StatefulWidget
{
  @override
  AnimationState createState()  => AnimationState();


}
class AnimationState extends State<MyAnimation> {

  void initState() {
    Timer(
        Duration(seconds: 8),
            () =>
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => FirstPage()))
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(

        child: Column(

          children: [


            Image.network("https://begrimed-executions.000webhostapp.com/images/splash_screen.jpg",
                alignment: Alignment.center,
            height: 700,
            width: 700,),

          ],
        ),
      ),
    );
  }
}

class FirstPage extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(title: Text("Home Page"),),
      body: Center(
        child: Column(
          children: [

            SizedBox(height: 300),

            Text("Splash Screen", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
          ],
        ),
      ),
    );
  }

}



