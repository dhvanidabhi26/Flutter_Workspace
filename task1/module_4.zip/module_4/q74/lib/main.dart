import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MyApp());
}

class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      home: FirstPage(),
      debugShowCheckedModeBanner: false,
    );
  }

}

class FirstPage extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(title: Text("This is First Page"),),
      body: Center(
        child: Column(
          children: [

            SizedBox(height: 250),

            Text("This is First Activity", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),

            SizedBox(height: 30),

            ElevatedButton(onPressed: ()
            {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SecondPage()));
            }, child: Text("Go to next Activity"),),
          ],
        ),
      ),
    );
  }

}

class SecondPage extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(title: Text("This is Second Page"),),
      body: Center(
        child: Column(
          children: [

            SizedBox(height: 250),

            Text("This is Second Activity", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),

            SizedBox(height: 30),

            ElevatedButton(onPressed: ()
            {
              Navigator.pop(context);
            }, child: Text("Go to First Page"),),
          ],
        ),
      ),
    );
  }

}
