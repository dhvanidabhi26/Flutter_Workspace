import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main()
{
  runApp(MyApp());
}

class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      home: LifeCycle(),
      debugShowCheckedModeBanner: false,
    );
  }

}

class LifeCycle extends StatefulWidget
{
  @override
  LifeCycleState createState() => LifeCycleState();


}

class LifeCycleState extends State<LifeCycle> with WidgetsBindingObserver
{

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addObserver(this);
  }

  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance?.removeObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);


    if (state == AppLifecycleState.resumed) {
      showToast("App Resumed");
    } if (state == AppLifecycleState.inactive) {
      showToast("App Inactive");
    } if (state == AppLifecycleState.paused) {
      showToast("App Paused");
    } if (state == AppLifecycleState.detached) {
      showToast("App Detached");
    }
  }

  void showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.grey,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  @override
  Widget build(BuildContext context)
  {


  return Scaffold(
      appBar: AppBar(title: Text("Activity LifeCycle"),),
      body: Center(
        child: Column(
          children: [
            
            SizedBox(height: 20),
            
            Image.network("https://begrimed-executions.000webhostapp.com/images/Activity_LifeCycle.png", height: 300, width: 300,)
          ],
        ),
      ),
    );
  }

}