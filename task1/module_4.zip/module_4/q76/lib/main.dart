import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:module4_sum/result.dart';

void main()
{
  runApp(MyApp());
}

class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      home: Input(),
      debugShowCheckedModeBanner: false,
    );
  }

}

class Input extends StatefulWidget
{
  @override
  InputState createState() => InputState();


}

class InputState extends State<Input>
{
  TextEditingController num1 = TextEditingController();
  TextEditingController num2 = TextEditingController();

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Home Page"),),

      body: Container(
        width: 300,
        height: 300,
        margin: EdgeInsets.all(30),
        padding: EdgeInsets.all(20),

        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
                offset: Offset(1.1, 1.1),
                blurRadius: 20.0,
                color: Colors.grey
            ),
          ],
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            TextField(
              controller: num1,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(label: Text("Enter First Number")),
            ),

            TextField(
              controller: num2,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(label: Text("Enter Second Number")),
            ),

            SizedBox(height: 25),

            ElevatedButton(onPressed: ()
            {
              double inputnum1 = double.tryParse(num1.text) ?? 0;
              double inputnum2 = double.tryParse(num2.text) ?? 0;
              double sum = inputnum1 + inputnum2;

              Navigator.push(context, MaterialPageRoute(builder: (context) => Result(sum)));
            } , child: Text("Calculate Sum"),

            ),
          ],
        ),
      ),
    );
  }

}