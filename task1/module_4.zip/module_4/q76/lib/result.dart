import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class Result extends StatelessWidget
{
  final double sum;

  Result(this.sum);

  @override
  Widget build(BuildContext context)

  {
    return Scaffold(

      appBar: AppBar(title: Text("Result Page"),),

      body: Center(

        child: Column(

          children: [

            SizedBox(height: 300),
            
            Text("The sum is $sum", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),

          ],
        ),
      ),
    );
  }

}
