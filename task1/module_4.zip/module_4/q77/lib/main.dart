import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main()
{
  runApp(MyApp());
}



class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
        home: MyPage(),
      debugShowCheckedModeBanner: false,
    );
  }


}

class MyPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tops Technologies"),),
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            SizedBox(height: 200),

            IconButton(onPressed: ()
            {
              call();

            }, icon: Icon(Icons.call, color: Colors.blue, size: 50.0,)),

            SizedBox(width: 90),

            IconButton(onPressed: ()
            {
              sms();

            }, icon: Icon(Icons.message, color: Colors.blue, size: 50.0,)),
          ],
        ),
      ),
    );
  }

  void call()
  {
    var url = Uri.parse("tel:8758268869");
    launchUrl(url);
  }

  void sms()
  {
    var url = Uri.parse("sms:8141355412");
    launchUrl(url);
  }
}